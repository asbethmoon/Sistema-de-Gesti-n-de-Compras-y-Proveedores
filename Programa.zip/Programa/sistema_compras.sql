-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-06-2025 a las 05:59:44
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistema_compras`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_orden`
--

CREATE TABLE `detalle_orden` (
  `id_detalle` int(11) NOT NULL,
  `id_orden` int(11) DEFAULT NULL,
  `producto` varchar(100) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio_unitario` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalle_orden`
--

INSERT INTO `detalle_orden` (`id_detalle`, `id_orden`, `producto`, `cantidad`, `precio_unitario`) VALUES
(1, 1, 'Laptop Lenovo ThinkPad', 5, 15499.00),
(2, 1, 'Mouse inalámbrico Logitech', 10, 399.00),
(3, 2, 'Laptop Lenovo ThinkPad', 2, 15499.00),
(4, 2, 'Teclado mecánico Redragon', 4, 899.00),
(5, 3, 'Mouse inalámbrico Logitech', 3, 399.00),
(6, 3, 'Teclado mecánico Redragon', 1, 899.00),
(7, 3, 'Monitor Dell 24 pulgadas', 2, 4599.00),
(8, 4, 'Laptop Lenovo ThinkPad', 1, 15499.00),
(9, 4, 'Mouse inalámbrico Logitech', 4, 399.00),
(10, 1, 'Cajas Blancas', 15, 12.50),
(13, 5, 'Papel', 15, 12.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `id_factura` int(11) NOT NULL,
  `numero_factura` varchar(50) NOT NULL,
  `fecha_emision` date DEFAULT NULL,
  `monto_total` decimal(10,2) DEFAULT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `estado_pago` enum('pendiente','pagado') DEFAULT NULL,
  `id_orden` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`id_factura`, `numero_factura`, `fecha_emision`, `monto_total`, `fecha_vencimiento`, `estado_pago`, `id_orden`) VALUES
(1, '1', '2025-05-01', 1500.00, '2025-05-31', 'pendiente', 1),
(2, '2', '2025-05-02', 1800.00, '2025-05-31', 'pagado', 2),
(4, '3', '2025-05-03', 1400.00, '2025-05-31', 'pendiente', 3),
(5, '3', '2025-05-29', 6500.00, '2025-06-08', 'pendiente', 6),
(6, '4', '2025-05-31', 850.00, '2025-06-02', '', 7),
(7, '5', '2025-06-08', 50.00, '2025-06-11', '', 8),
(8, '6', '2025-05-29', 4362.20, '2025-06-07', 'pendiente', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion`
--

CREATE TABLE `notificacion` (
  `id_notificacion` int(11) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha_generacion` date DEFAULT NULL,
  `id_orden` int(11) DEFAULT NULL,
  `estado` varchar(20) DEFAULT 'activa'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `notificacion`
--

INSERT INTO `notificacion` (`id_notificacion`, `tipo`, `descripcion`, `fecha_generacion`, `id_orden`, `estado`) VALUES
(1, 'entrega', 'La orden #5 está próxima a su fecha de entrega.', '2025-05-29', 5, 'activa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orden_compra`
--

CREATE TABLE `orden_compra` (
  `id_orden` int(11) NOT NULL,
  `fecha_orden` date NOT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `estado` enum('pendiente','enviada','entregada','cancelada') DEFAULT NULL,
  `fecha_entrega_estimada` date NOT NULL COMMENT 'Fecha estimada para la entrega del pedido'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `orden_compra`
--

INSERT INTO `orden_compra` (`id_orden`, `fecha_orden`, `id_proveedor`, `estado`, `fecha_entrega_estimada`) VALUES
(1, '2025-04-30', 1, 'pendiente', '2025-05-13'),
(2, '2025-05-01', 2, 'enviada', '2025-05-13'),
(3, '2025-05-02', 3, 'cancelada', '2025-05-13'),
(4, '2025-05-03', 4, 'pendiente', '2025-05-13'),
(5, '2025-05-28', 5, 'cancelada', '2025-05-30'),
(6, '2025-06-01', 9, 'cancelada', '2025-06-01'),
(7, '2025-06-01', 11, 'cancelada', '2025-05-09'),
(8, '2025-06-01', 1, 'cancelada', '2025-06-08'),
(9, '2025-06-01', 9, 'cancelada', '2025-06-12');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `id_proveedor` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `rfc` varchar(20) DEFAULT NULL,
  `direccion` varchar(150) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `estatus` enum('activo','inactivo') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`id_proveedor`, `nombre`, `rfc`, `direccion`, `telefono`, `correo`, `estatus`) VALUES
(1, 'Comercializadora del Valle', 'CVV8801239K0', 'Av. Reforma 123, CDMX', '555-123-4567', 'contacto@cdvalle.mx', 'activo'),
(2, 'Insumos Médicos Fénix', 'IMF920501AA2', 'Calle Salud 45, Monterrey', '818-456-7890', 'ventas@fenixmed.com', 'activo'),
(3, 'Papelería Águila', 'PAG740219ZL5', 'Av. Central 987, Guadalajara', '333-222-1111', 'contacto@papelaguila.com', 'activo'),
(4, 'Tecnología Luna', 'TLU850319MF7', 'Calle Sol 202, CDMX', '555-987-6543', 'info@tecluna.com.mx', 'activo'),
(5, 'Materiales Olivares', 'MTO970710EJ1', 'Blvd. Industrial 300, Puebla', '222-123-4560', 'ventas@molivares.mx', 'activo'),
(6, 'Servicios Informáticos Nova', 'SIN900615TX3', 'Parque Tecnológico 7, León', '477-445-3344', 'contacto@sinova.com', 'activo'),
(7, 'Proveedora Alimentaria Sur', 'PAS830201PP0', 'Camino Real 88, Mérida', '999-888-7777', 'pedidos@alimentariasur.mx', 'activo'),
(8, 'ConstruMarket SA', 'CMS920404ZQ2', 'Av. Obra Pública 456, Querétaro', '442-332-2211', 'ventas@constru-market.com', 'activo'),
(9, 'Bimbo', NULL, NULL, '5530748997', 'stef-99-@live.com', NULL),
(10, 'Tlapaleria los hermanos', '1564232649484', 'Esquina colinas, 30-b, manzana v', '5551167463', 'kikamaravillosa2014@gmail.com', 'activo'),
(11, 'Pinturas Comex', 'sdfsf61asasd1', 'colinas de tierra blanca, no. 14, 9b', '5512328754', 'pinturas@gmail.com', 'activo'),
(12, 'Price shoes', 'adwdafgasgds4', 'Tierra blanca, jose recuelta', '123258675', 'priceshoes@gmail.com', 'activo'),
(13, 'Toyota', 'ashjadvv5dssi8', 'Av. morelos, no. 44, ecatepec de morelos', '5564238467', 'toyota@gmail.com', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `contraseña` varchar(255) DEFAULT NULL,
  `rol` varchar(50) DEFAULT NULL,
  `fecha_registro` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre`, `correo`, `contraseña`, `rol`, `fecha_registro`) VALUES
(2, 'Christian Ricardo Escalante Guzman', 'elchriseg@gmail.com', '$2y$10$MK8DZ./vlsLkbaBk8BUy/.1RMICy5Sg0iewS102GrjcsJdkkgd3aW', 'empleado', '2025-05-30 21:03:23'),
(3, 'Karen Asbeth Montoya Coronel', 'asbethmoon@gmail.com', '$2y$10$QzYvWGuY41TcxjIGdpCQ4O2oo7EgvAN4OF.4sbj4/lzEiOgBKf/im', 'administrador', '2025-05-30 23:23:48'),
(4, 'Caleb Torres Mendoza', 'calebmendez55@gmail.com', '$2y$10$EsAexoGhP2X2QPgKlgojs.yKcYv3UvhJOzDS/hleM4b78rqRLAc5m', 'administrador', '2025-05-30 23:32:56'),
(5, 'Analleli Quetzalcoateco Meneses', 'analleliquetzalcoateco@gmail.com', '$2y$10$SVi0CDc39GA.vRjb2X6ilumYR8cMoJmrq0VPGsJPX5s1X3l9QsYYu', 'empleado', '2025-05-30 23:33:50'),
(6, 'Victor Hugo Garcia Delgadillo', 'vectormen01@gmail.com', '$2y$10$G3g23MLrIV08YvHI.en1xecfqXEHrKwSQlPvNhnghdRfyJGd2hBoe', 'empleado', '2025-05-30 23:43:20'),
(7, 'Asbeth Montoya', 'montoyakaren0502@gmail.com', '$2y$10$DdugUkhDQLw7bUjoPRrhIesrZlyTct95zVuFOxjDQb8eyujS4d5aK', 'administrador', '2025-05-31 17:30:48'),
(9, 'Asbeth Montoya', 'kikamaravillosa2014@gmail.com', '123456', 'admin', '2025-06-01 00:00:00'),
(12, 'Angel Gabriel', 'gabrielg21lopez@gmail.com', '123456', 'empleado', '2025-06-01 00:00:00'),
(14, 'Escalante Guzman', 'chris55eg@gmail.com', '123456', 'admin', '2025-06-01 00:00:00'),
(15, 'Victor Hugo Garcia Delgadillo', 'hugarcillo@gmail.com', '123456', 'empleado', '2025-06-01 00:00:00');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `detalle_orden`
--
ALTER TABLE `detalle_orden`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `id_orden` (`id_orden`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`id_factura`);

--
-- Indices de la tabla `notificacion`
--
ALTER TABLE `notificacion`
  ADD PRIMARY KEY (`id_notificacion`),
  ADD KEY `id_orden` (`id_orden`);

--
-- Indices de la tabla `orden_compra`
--
ALTER TABLE `orden_compra`
  ADD PRIMARY KEY (`id_orden`),
  ADD KEY `id_proveedor` (`id_proveedor`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`id_proveedor`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalle_orden`
--
ALTER TABLE `detalle_orden`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `id_factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `notificacion`
--
ALTER TABLE `notificacion`
  MODIFY `id_notificacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `orden_compra`
--
ALTER TABLE `orden_compra`
  MODIFY `id_orden` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  MODIFY `id_proveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `detalle_orden`
--
ALTER TABLE `detalle_orden`
  ADD CONSTRAINT `detalle_orden_ibfk_1` FOREIGN KEY (`id_orden`) REFERENCES `orden_compra` (`id_orden`);

--
-- Filtros para la tabla `notificacion`
--
ALTER TABLE `notificacion`
  ADD CONSTRAINT `notificacion_ibfk_1` FOREIGN KEY (`id_orden`) REFERENCES `orden_compra` (`id_orden`);

--
-- Filtros para la tabla `orden_compra`
--
ALTER TABLE `orden_compra`
  ADD CONSTRAINT `orden_compra_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id_proveedor`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
