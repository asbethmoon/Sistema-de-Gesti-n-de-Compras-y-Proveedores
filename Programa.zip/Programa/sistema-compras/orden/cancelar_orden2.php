<?php
include('../config/conexion.php');

if (isset($_GET['id'])) {
    $id_orden = $_GET['id'];

    // Cambiar el estado de la orden a "cancelada"
    $sql = "UPDATE orden_compra SET estado = 'cancelada' WHERE id_orden = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_orden);

    if ($stmt->execute()) {
        // Redirigir de regreso al listado
        header("Location: listar_ordenes2.php");
        exit();
    } else {
        echo "❌ Error al cancelar la orden.";
    }
} else {
    echo "⚠️ ID de orden no proporcionado.";
}
?>