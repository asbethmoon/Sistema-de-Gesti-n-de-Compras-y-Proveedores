<?php
include('../config/conexion.php');

$fecha_orden = $_POST['fecha_orden'];
$fecha_entrega = $_POST['fecha_entrega_estimada'];
$id_proveedor = $_POST['id_proveedor'];
$estado = $_POST['estado'];

$sql = "INSERT INTO orden_compra (fecha_orden, fecha_entrega_estimada, id_proveedor, estado)
        VALUES ('$fecha_orden', '$fecha_entrega', '$id_proveedor', '$estado')";

if (mysqli_query($conn, $sql)) {
    echo "✅ Orden registrada con éxito.";
} else {
    echo "❌ Error al registrar la orden: " . mysqli_error($conn);
}

mysqli_close($conn);
?>