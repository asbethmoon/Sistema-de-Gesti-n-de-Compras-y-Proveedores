<?php
include('../config/conexion.php');

$ordenes = $conn->query("
  SELECT o.id_orden, p.nombre AS proveedor, o.fecha_entrega_estimada, o.estado
  FROM orden_compra o
  JOIN proveedor p ON o.id_proveedor = p.id_proveedor
  ORDER BY o.id_orden DESC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Órdenes de Compra</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #eef2f3;
      padding: 30px;
    }

    h2 {
      text-align: center;
      margin-bottom: 30px;
      color: #2c3e50;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    th, td {
      padding: 12px 15px;
      border-bottom: 1px solid #ddd;
      text-align: center;
    }

    th {
      background-color: #3498db;
      color: white;
    }

    tr:hover {
      background-color: #f1f1f1;
    }

    .volver {
      display: inline-block;
      margin-bottom: 15px;
      padding: 10px 18px;
      background-color: #2ecc71;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      font-weight: bold;
    }

    .volver:hover {
      background-color: #27ae60;
    }

    .estado-pendiente {
      color: #e67e22;
      font-weight: bold;
    }

    .estado-completada {
      color: #27ae60;
      font-weight: bold;
    }

    .estado-cancelada {
      color: #c0392b;
      font-weight: bold;
    }

    .acciones a {
      text-decoration: none;
      padding: 6px 10px;
      margin: 0 5px;
      border-radius: 5px;
      font-size: 14px;
    }

    .editar {
      background-color: #2980b9;
      color: white;
    }

    .editar:hover {
      background-color: #1f6391;
    }

    .cancelar {
      background-color: #e74c3c;
      color: white;
    }

    .cancelar:hover {
      background-color: #c0392b;
    }
  </style>
</head>
<body>

<a class="volver" href="../empleado_panel.php">← Volver al panel</a>

<h2>Órdenes de Compra Registradas</h2>

<table>
  <thead>
    <tr>
      <th>ID</th>
      <th>Proveedor</th>
      <th>Fecha de Entrega</th>
      <th>Estado</th>
      <th>Acciones</th>
    </tr>
  </thead>
  <tbody>
    <?php while ($orden = $ordenes->fetch_assoc()) {
      $estadoClass = 'estado-' . strtolower($orden['estado']);
    ?>
      <tr>
        <td><?php echo $orden['id_orden']; ?></td>
        <td><?php echo htmlspecialchars($orden['proveedor']); ?></td>
        <td><?php echo $orden['fecha_entrega_estimada']; ?></td>
        <td class="<?php echo $estadoClass; ?>"><?php echo ucfirst($orden['estado']); ?></td>
        <td class="acciones">
          <a class="editar" href="editar_orden2.php?id=<?php echo $orden['id_orden']; ?>">Editar</a>
          <a class="cancelar" href="cancelar_orden2.php?id=<?php echo $orden['id_orden']; ?>" onclick="return confirm('¿Estás seguro de cancelar esta orden?');">Cancelar</a>
        </td>
      </tr>
    <?php } ?>
  </tbody>
</table>

</body>
</html>
