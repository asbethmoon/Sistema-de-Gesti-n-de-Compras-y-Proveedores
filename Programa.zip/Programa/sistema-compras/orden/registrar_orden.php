A<?php
include('../config/conexion.php');

$mensaje = '';

// Obtener proveedores
$proveedores = $conn->query("SELECT id_proveedor, nombre FROM proveedor");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_proveedor = $_POST['id_proveedor'];
    $fecha_entrega = $_POST['fecha_entrega_estimada'];
    $estado = 'pendiente';
    $fecha_orden = date('Y-m-d');

    $sql = "INSERT INTO orden_compra (fecha_orden, id_proveedor, estado, fecha_entrega_estimada)
            VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siss", $fecha_orden, $id_proveedor, $estado, $fecha_entrega);

    if ($stmt->execute()) {
        $mensaje = "✅ Orden registrada correctamente.";
    } else {
        $mensaje = "❌ Error al registrar la orden: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registrar Orden de Compra</title>
  <style>
    body {
      background: linear-gradient(to right, #e0f7fa, #ffffff);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
    }

    .formulario {
      background-color: #ffffff;
      padding: 35px;
      border-radius: 16px;
      box-shadow: 0 8px 18px rgba(0, 0, 0, 0.1);
      width: 480px;
    }

    h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #2c3e50;
    }

    label {
      font-weight: bold;
      margin-top: 10px;
      display: block;
    }

    select, input[type="date"], input[type="submit"] {
      width: 100%;
      padding: 12px;
      margin-top: 6px;
      margin-bottom: 20px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 15px;
    }

    input[type="submit"] {
      background-color: #3498db;
      color: white;
      font-weight: bold;
      border: none;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    input[type="submit"]:hover {
      background-color: #2980b9;
    }

    .mensaje {
      text-align: center;
      color: #2ecc71;
      font-weight: bold;
      margin-top: 10px;
    }

    .volver {
      display: block;
      width: 100%;
      text-align: center;
      background-color: #2ecc71;
      color: white;
      font-weight: bold;
      padding: 10px;
      margin-top: 15px;
      border-radius: 8px;
      text-decoration: none;
      transition: background-color 0.3s ease;
    }

    .volver:hover {
      background-color: #27ae60;
    }

    .secundario {
      background-color: #95a5a6;
    }

    .secundario:hover {
      background-color: #7f8c8d;
    }
  </style>
</head>
<body>

<div class="formulario">
  <h2>📝 Registrar Orden de Compra</h2>

  <form method="POST">
    <label for="id_proveedor">Proveedor:</label>
    <select name="id_proveedor" required>
      <option value="">Selecciona un proveedor</option>
      <?php while ($prov = $proveedores->fetch_assoc()) { ?>
        <option value="<?php echo $prov['id_proveedor']; ?>">
          <?php echo htmlspecialchars($prov['nombre']); ?>
        </option>
      <?php } ?>
    </select>

    <label for="fecha_entrega_estimada">Fecha estimada de entrega:</label>
    <input type="date" name="fecha_entrega_estimada" required>

    <input type="submit" value="Registrar Orden">
  </form>

  <?php if ($mensaje): ?>
    <div class="mensaje"><?php echo $mensaje; ?></div>
  <?php endif; ?>

  <a class="volver secundario" href="listar_ordenes.php">📋 Ver listado de órdenes</a>
  <a class="volver" href="../admin_panel.php">🏠 Volver al menú administrador</a>
</div>

</body>
</html>