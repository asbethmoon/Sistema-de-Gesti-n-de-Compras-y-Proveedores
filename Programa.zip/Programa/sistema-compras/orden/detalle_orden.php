<?php
include('../config/conexion.php');

// Mensaje para mostrar al usuario
$mensaje = '';

// Eliminar detalle
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $conn->query("DELETE FROM detalle_orden WHERE id_detalle = $id");
    $mensaje = "✅ Detalle eliminado.";
}

// Insertar nuevo detalle
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_orden = $_POST['id_orden'];
    $producto = $_POST['producto'];
    $cantidad = $_POST['cantidad'];
    $precio = $_POST['precio_unitario'];

    $stmt = $conn->prepare("INSERT INTO detalle_orden (id_orden, producto, cantidad, precio_unitario)
                            VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isid", $id_orden, $producto, $cantidad, $precio);
    if ($stmt->execute()) {
        $mensaje = "✅ Detalle registrado correctamente.";
    } else {
        $mensaje = "❌ Error al registrar detalle: " . $stmt->error;
    }
}

// Obtener todos los detalles
$detalles = $conn->query("SELECT * FROM detalle_orden ORDER BY id_detalle DESC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Detalle de Órdenes</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f2f6fa;
      padding: 40px;
    }

    .container {
      max-width: 900px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 25px;
    }

    form {
      margin-bottom: 30px;
    }

    label {
      font-weight: bold;
    }

    input, select {
      width: 100%;
      padding: 10px;
      margin-top: 6px;
      margin-bottom: 15px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 15px;
    }

    input[type="submit"] {
      background-color: #3498db;
      color: white;
      font-weight: bold;
      border: none;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: #2980b9;
    }

    .mensaje {
      text-align: center;
      font-weight: bold;
      margin-bottom: 20px;
      color: green;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 10px;
    }

    th, td {
      padding: 12px;
      text-align: center;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #34495e;
      color: white;
    }

    tr:hover {
      background-color: #ecf0f1;
    }

    .eliminar {
      color: white;
      background-color: #e74c3c;
      padding: 6px 12px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
    }

    .eliminar:hover {
      background-color: #c0392b;
    }

    .volver {
      display: inline-block;
      margin-top: 20px;
      background-color: #2ecc71;
      color: white;
      text-decoration: none;
      font-weight: bold;
      padding: 10px 16px;
      border-radius: 8px;
    }

    .volver:hover {
      background-color: #27ae60;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>📦 Detalle de Órdenes</h2>

  <?php if ($mensaje): ?>
    <div class="mensaje"><?php echo $mensaje; ?></div>
  <?php endif; ?>

  <form method="POST">
    <label for="id_orden">ID Orden:</label>
    <input type="number" name="id_orden" required>

    <label for="producto">Producto:</label>
    <input type="text" name="producto" required>

    <label for="cantidad">Cantidad:</label>
    <input type="number" name="cantidad" required min="1">

    <label for="precio_unitario">Precio Unitario:</label>
    <input type="number" step="0.01" name="precio_unitario" required>

    <input type="submit" value="Agregar Detalle">
  </form>

  <table>
    <thead>
      <tr>
        <th>ID Detalle</th>
        <th>ID Orden</th>
        <th>Producto</th>
        <th>Cantidad</th>
        <th>Precio Unitario</th>
        <th>Eliminar</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($fila = $detalles->fetch_assoc()) { ?>
        <tr>
          <td><?php echo $fila['id_detalle']; ?></td>
          <td><?php echo $fila['id_orden']; ?></td>
          <td><?php echo htmlspecialchars($fila['producto']); ?></td>
          <td><?php echo $fila['cantidad']; ?></td>
          <td>$<?php echo number_format($fila['precio_unitario'], 2); ?></td>
          <td><a class="eliminar" href="?eliminar=<?php echo $fila['id_detalle']; ?>" onclick="return confirm('¿Eliminar este detalle?');">Eliminar</a></td>
        </tr>
      <?php } ?>
    </tbody>
  </table>

  <a class="volver" href="../admin_panel.php">← Volver al menú administrador</a>
</div>

</body>
</html>