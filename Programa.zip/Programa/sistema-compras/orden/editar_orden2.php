<?php
include('../config/conexion.php');

$mensaje = '';

// Verificamos si viene el ID de la orden por la URL
if (!isset($_GET['id'])) {
    echo "❌ No se proporcionó ID de orden.";
    exit();
}

$id_orden = $_GET['id'];

// Primero recuperamos los datos actuales
$sql = "SELECT * FROM orden_compra WHERE id_orden = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_orden);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    echo "⚠️ Orden no encontrada.";
    exit();
}

$orden = $resultado->fetch_assoc();

// Si el formulario fue enviado, actualizamos
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nuevo_estado = $_POST['estado'];
    $nueva_fecha = $_POST['fecha_entrega_estimada'];

    $update = $conn->prepare("UPDATE orden_compra SET estado = ?, fecha_entrega_estimada = ? WHERE id_orden = ?");
    $update->bind_param("ssi", $nuevo_estado, $nueva_fecha, $id_orden);

    if ($update->execute()) {
        $mensaje = "✅ Orden actualizada correctamente.";
        // Actualizar datos mostrados
        $orden['estado'] = $nuevo_estado;
        $orden['fecha_entrega_estimada'] = $nueva_fecha;
    } else {
        $mensaje = "❌ Error al actualizar orden.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Editar Orden</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f2f2f2;
      padding: 40px;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .formulario {
      background-color: white;
      padding: 30px;
      border-radius: 12px;
      width: 400px;
      box-shadow: 0 0 12px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 25px;
    }

    label {
      font-weight: bold;
    }

    select, input[type="date"] {
      width: 100%;
      padding: 10px;
      margin: 10px 0 20px;
      border: 1px solid #ccc;
      border-radius: 8px;
    }

    input[type="submit"] {
      width: 100%;
      background-color: #3498db;
      color: white;
      padding: 12px;
      font-weight: bold;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: 0.3s;
    }

    input[type="submit"]:hover {
      background-color: #2980b9;
    }

    .mensaje {
      text-align: center;
      color: green;
      font-weight: bold;
      margin-bottom: 15px;
    }

    .volver {
      display: block;
      margin-top: 20px;
      text-align: center;
      text-decoration: none;
      color: #3498db;
      font-weight: bold;
    }
  </style>
</head>
<body>

<div class="formulario">
  <h2>Editar Orden #<?php echo $orden['id_orden']; ?></h2>

  <?php if ($mensaje): ?>
    <div class="mensaje"><?php echo $mensaje; ?></div>
  <?php endif; ?>

  <form method="POST">
    <label for="estado">Estado:</label>
    <select name="estado" required>
      <option value="pendiente" <?php if ($orden['estado'] === 'pendiente') echo 'selected'; ?>>Pendiente</option>
      <option value="completada" <?php if ($orden['estado'] === 'completada') echo 'selected'; ?>>Completada</option>
      <option value="cancelada" <?php if ($orden['estado'] === 'cancelada') echo 'selected'; ?>>Cancelada</option>
    </select>

    <label for="fecha_entrega_estimada">Fecha de entrega estimada:</label>
    <input type="date" name="fecha_entrega_estimada" value="<?php echo $orden['fecha_entrega_estimada']; ?>" required>

    <input type="submit" value="Actualizar Orden">
  </form>

  <a class="volver" href="listar_ordenes2.php">← Volver al listado</a>
</div>

</body>
</html>