<?php
session_start();
include('config/conexion.php');
$mensaje = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    $sql = "SELECT * FROM usuario WHERE correo = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $resultado = $stmt->get_result();
    if ($resultado->num_rows === 1) {
        $usuario = $resultado->fetch_assoc();
        if (password_verify($contrasena, $usuario['contraseña'])) {
            $_SESSION['usuario'] = $usuario['nombre'];
            $_SESSION['rol'] = $usuario['rol'];
            $_SESSION['correo'] = $usuario['correo'];

            if ($usuario['rol'] === 'administrador') {
                header("Location: admin_panel.php");
            } else {
                header("Location: empleado_panel.php");
            }
            exit();
        } else {
            $mensaje = "❌ Contraseña incorrecta.";
        }
    } else {
        $mensaje = "❌ Usuario no encontrado.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Iniciar Sesión</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #74ebd5, #ACB6E5);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .login-box {
      background: white;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 0 20px rgba(0,0,0,0.2);
      text-align: center;
      width: 350px;
    }
    h2 {
      color: #2c3e50;
      margin-bottom: 20px;
    }
    input {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 15px;
    }
    input[type="submit"] {
      background-color: #3498db;
      color: white;
      font-weight: bold;
      cursor: pointer;
      border: none;
      transition: 0.3s;
    }
    input[type="submit"]:hover {
      background-color: #2980b9;
    }
    .mensaje {
      color: red;
      margin-top: 10px;
      font-weight: bold;
    }
    .regresar {
      position: absolute;
      top: 20px;
      left: 20px;
      background: white;
      color: #3498db;
      padding: 8px 16px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      border: 2px solid #3498db;
      transition: 0.3s;
    }
    .regresar:hover {
      background-color: #3498db;
      color: white;
    }
  </style>
</head>
<body>
<a href="index.php" class="regresar">← Menú principal</a>
<div class="login-box">
  <h2>🔐 Iniciar sesión</h2>
  <form method="POST">
    <input type="email" name="correo" placeholder="Correo electrónico" required>
    <input type="password" name="contrasena" placeholder="Contraseña" required>
    <input type="submit" value="Entrar">
  </form>
  <div class="mensaje"><?php echo $mensaje; ?></div>
</div>
</body>
</html>