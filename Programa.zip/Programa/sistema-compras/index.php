<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Sistema de Compras - Bienvenida</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: linear-gradient(145deg, #2980b9, #6dd5fa);
      margin: 0;
      padding: 0;
      color: white;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .container {
      text-align: center;
      background-color: rgba(255, 255, 255, 0.1);
      padding: 40px;
      border-radius: 20px;
      box-shadow: 0 0 20px rgba(0,0,0,0.2);
    }
    h1 {
      margin-bottom: 30px;
    }
    .botones {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin-top: 20px;
    }
    .botones a {
      padding: 12px 25px;
      background-color: white;
      color: #2980b9;
      font-weight: bold;
      text-decoration: none;
      border-radius: 10px;
      transition: 0.3s;
    }
    .botones a:hover {
      background-color: #3498db;
      color: white;
    }
  </style>
</head>
<body>

  <div class="container">
    <h1>🎉 Bienvenido al Sistema de Gestión de Compras</h1>
    <div class="botones">
      <a href="login.php">Iniciar sesión</a>
    </div>
  </div>

</body>
</html>