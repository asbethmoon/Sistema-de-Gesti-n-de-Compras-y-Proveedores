<?php
include('../config/conexion.php');

$resultado = $conn->query("
  SELECT producto, SUM(cantidad) AS total_adquirido
  FROM detalle_orden
  GROUP BY producto
  ORDER BY total_adquirido DESC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>📦 Productos más adquiridos</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f0f4f8;
      padding: 40px;
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: #fff;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    th, td {
      padding: 14px;
      text-align: center;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #34495e;
      color: white;
    }

    tr:hover {
      background-color: #ecf0f1;
    }

    .volver {
      display: inline-block;
      margin-bottom: 20px;
      padding: 10px 16px;
      background-color: #2ecc71;
      color: white;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
    }

    .volver:hover {
      background-color: #27ae60;
    }

    .mensaje {
      text-align: center;
      color: #888;
      font-size: 18px;
      margin-top: 30px;
    }
  </style>
</head>
<body>

<a class="volver" href="../empleado_panel.php">← Volver al panel</a>

<h2>📦 Productos Más Adquiridos</h2>

<?php if ($resultado && $resultado->num_rows > 0): ?>
  <table>
    <thead>
      <tr>
        <th>Producto</th>
        <th>Total Adquirido</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($fila = $resultado->fetch_assoc()) { ?>
        <tr>
          <td><?php echo htmlspecialchars($fila['producto']); ?></td>
          <td><?php echo $fila['total_adquirido']; ?></td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
<?php else: ?>
  <div class="mensaje">No hay productos registrados o adquiridos aún.</div>
<?php endif; ?>

</body>
</html>