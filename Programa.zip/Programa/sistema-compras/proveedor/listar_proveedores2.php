<?php
include('../config/conexion.php');
$sql = "SELECT * FROM proveedor";
$resultado = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Lista de Proveedores</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #f8f9fa, #dde6f3);
      margin: 0;
      padding: 30px;
    }
    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }
    .tabla-contenedor {
      max-width: 1000px;
      margin: auto;
      background-color: white;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
      overflow-x: auto;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    th, td {
      padding: 12px;
      border-bottom: 1px solid #ccc;
      text-align: left;
    }
    th {
      background-color: #2980b9;
      color: white;
    }
    tr:hover {
      background-color: #f2f2f2;
    }
    .regresar {
      display: inline-block;
      margin-bottom: 20px;
      background: white;
      color: #2980b9;
      padding: 8px 16px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      border: 2px solid #2980b9;
      transition: 0.3s;
    }
    .regresar:hover {
      background-color: #2980b9;
      color: white;
    }
  </style>
</head>
<body>
<div class="tabla-contenedor">
  <a href="../empleado_panel.php" class="regresar">← Volver al panel</a>
  <h2>📋 Lista de Proveedores Registrados</h2>
  <table>
    <thead>
      <tr>
        <th>Nombre</th>
        <th>Teléfono</th>
        <th>Correo</th>
        <th>RFC</th>
        <th>Dirección</th>
        <th>Estatus</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($fila = $resultado->fetch_assoc()) { ?>
        <tr>
          <td><?php echo htmlspecialchars($fila['nombre']); ?></td>
          <td><?php echo htmlspecialchars($fila['telefono']); ?></td>
          <td><?php echo htmlspecialchars($fila['correo']); ?></td>
          <td><?php echo htmlspecialchars($fila['rfc']); ?></td>
          <td><?php echo htmlspecialchars($fila['direccion']); ?></td>
          <td><?php echo htmlspecialchars($fila['estatus']); ?></td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
</div>
</body>
</html>