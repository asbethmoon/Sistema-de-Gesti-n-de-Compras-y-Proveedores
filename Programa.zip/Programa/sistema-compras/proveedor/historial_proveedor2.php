<?php
include('../config/conexion.php');

$mensaje = '';
$ordenes = [];

// Obtener todos los proveedores
$proveedores = $conn->query("SELECT id_proveedor, nombre FROM proveedor ORDER BY nombre");

// Si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_proveedor = $_POST['id_proveedor'];

    // Obtener las órdenes del proveedor
    $stmt = $conn->prepare("
        SELECT id_orden, fecha_orden, fecha_entrega_estimada, estado
        FROM orden_compra
        WHERE id_proveedor = ?
        ORDER BY fecha_orden DESC
    ");
    $stmt->bind_param("i", $id_proveedor);
    $stmt->execute();
    $ordenes = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Historial de Compras por Proveedor</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f7fb;
      padding: 40px;
    }

    .contenedor {
      max-width: 900px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 12px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    form {
      margin-bottom: 20px;
      text-align: center;
    }

    select, input[type="submit"] {
      padding: 10px;
      font-size: 16px;
      margin: 0 10px;
      border-radius: 8px;
      border: 1px solid #ccc;
    }

    input[type="submit"] {
      background-color: #3498db;
      color: white;
      font-weight: bold;
      cursor: pointer;
    }

    input[type="submit"]:hover {
      background-color: #2980b9;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 12px;
      border-bottom: 1px solid #ddd;
      text-align: center;
    }

    th {
      background-color: #3498db;
      color: white;
    }

    .volver {
      display: inline-block;
      margin-bottom: 20px;
      text-decoration: none;
      color: #3498db;
      font-weight: bold;
    }

    .estado-pendiente { color: #e67e22; font-weight: bold; }
    .estado-completada { color: #27ae60; font-weight: bold; }
    .estado-cancelada { color: #c0392b; font-weight: bold; }
  </style>
</head>
<body>

<div class="contenedor">
  <a class="volver" href="../empleado_panel.php">← Volver al panel</a>

  <h2>📦 Historial de Órdenes por Proveedor</h2>

  <form method="POST">
    <label for="id_proveedor">Selecciona un proveedor:</label>
    <select name="id_proveedor" required>
      <option value="">-- Selecciona --</option>
      <?php while ($prov = $proveedores->fetch_assoc()) { ?>
        <option value="<?php echo $prov['id_proveedor']; ?>" <?php if (isset($id_proveedor) && $id_proveedor == $prov['id_proveedor']) echo 'selected'; ?>>
          <?php echo htmlspecialchars($prov['nombre']); ?>
        </option>
      <?php } ?>
    </select>
    <input type="submit" value="Consultar">
  </form>

  <?php if ($ordenes && $ordenes->num_rows > 0): ?>
    <table>
      <thead>
        <tr>
          <th>ID Orden</th>
          <th>Fecha Orden</th>
          <th>Fecha Entrega Estimada</th>
          <th>Estado</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($orden = $ordenes->fetch_assoc()) {
          $estadoClass = 'estado-' . strtolower($orden['estado']);
        ?>
          <tr>
            <td><?php echo $orden['id_orden']; ?></td>
            <td><?php echo $orden['fecha_orden']; ?></td>
            <td><?php echo $orden['fecha_entrega_estimada']; ?></td>
            <td class="<?php echo $estadoClass; ?>"><?php echo ucfirst($orden['estado']); ?></td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
    <p style="text-align:center; color:gray;">Este proveedor no tiene órdenes registradas.</p>
  <?php endif; ?>
</div>

</body>
</html>