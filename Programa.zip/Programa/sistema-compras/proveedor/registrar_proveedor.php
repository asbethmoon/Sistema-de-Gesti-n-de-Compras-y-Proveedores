<?php
include('../config/conexion.php');
$mensaje = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $correo = $_POST['correo'];
    $rfc = $_POST['rfc'];
    $direccion = $_POST['direccion'];
    $estatus = $_POST['estatus'];
    $sql = "INSERT INTO proveedor (nombre, telefono, correo, rfc, direccion, estatus) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $nombre, $telefono, $correo, $rfc, $direccion, $estatus);
    if ($stmt->execute()) {
        $mensaje = "✅ Proveedor registrado correctamente.";
    } else {
        $mensaje = "❌ Error al registrar proveedor: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registrar Proveedor</title>
  <style>
    body {
      background: linear-gradient(135deg, #dbe6f6, #c5796d);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .formulario {
      background-color: white;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 0 15px rgba(0,0,0,0.2);
      width: 450px;
      text-align: center;
    }
    h2 {
      margin-bottom: 20px;
      color: #2c3e50;
    }
    input, select, textarea {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 15px;
    }
    input[type="submit"] {
      background-color: #2980b9;
      color: white;
      font-weight: bold;
      cursor: pointer;
      border: none;
      transition: 0.3s;
    }
    input[type="submit"]:hover {
      background-color: #21618c;
    }
    .mensaje {
      margin-top: 15px;
      font-weight: bold;
      color: green;
    }
    .regresar {
      position: absolute;
      top: 20px;
      left: 20px;
      background: white;
      color: #2980b9;
      padding: 8px 16px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      border: 2px solid #2980b9;
      transition: 0.3s;
    }
    .regresar:hover {
      background-color: #2980b9;
      color: white;
    }
  </style>
</head>
<body>
<a href="../admin_panel.php" class="regresar">← Volver al panel</a>
<div class="formulario">
  <h2>Registrar nuevo proveedor</h2>
  <form method="POST">
    <input type="text" name="nombre" placeholder="Nombre del proveedor" required>
    <input type="text" name="telefono" placeholder="Teléfono" required>
    <input type="email" name="correo" placeholder="Correo electrónico" required>
    <input type="text" name="rfc" placeholder="RFC" required>
    <textarea name="direccion" placeholder="Dirección completa" required></textarea>
    <select name="estatus" required>
      <option value="">Seleccione estatus</option>
      <option value="Activo">Activo</option>
      <option value="Inactivo">Inactivo</option>
    </select>
    <input type="submit" value="Registrar">
  </form>
  <div class="mensaje"><?php echo $mensaje; ?></div>
</div>
</body>
</html>