<?php
include('../config/conexion.php');

$mensaje = '';

// Obtener órdenes activas
$ordenes = $conn->query("SELECT id_orden FROM orden_compra WHERE estado != 'cancelada'");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $numero = $_POST['numero_factura'];
    $fecha_emision = $_POST['fecha_emision'];
    $monto = $_POST['monto_total'];
    $fecha_vencimiento = $_POST['fecha_vencimiento'];
    $estado_pago = $_POST['estado_pago'];
    $id_orden = $_POST['id_orden'];

    $sql = "INSERT INTO factura (numero_factura, fecha_emision, monto_total, fecha_vencimiento, estado_pago, id_orden)
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssdssi", $numero, $fecha_emision, $monto, $fecha_vencimiento, $estado_pago, $id_orden);

    if ($stmt->execute()) {
        $mensaje = "✅ Factura registrada correctamente.";
    } else {
        $mensaje = "❌ Error al registrar factura: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registrar Factura</title>
  <style>
    body {
      background: linear-gradient(135deg, #e8f0fe, #fef9f9);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .formulario {
      background-color: white;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
      width: 480px;
    }

    h2 {
      text-align: center;
      margin-bottom: 25px;
      color: #2c3e50;
    }

    label {
      font-weight: bold;
    }

    input, select {
      width: 100%;
      padding: 12px;
      margin-bottom: 15px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 15px;
    }

    input[type="submit"] {
      background-color: #3498db;
      color: white;
      font-weight: bold;
      cursor: pointer;
      border: none;
      transition: background-color 0.3s ease;
    }

    input[type="submit"]:hover {
      background-color: #2980b9;
    }

    .mensaje {
      text-align: center;
      margin-top: 15px;
      color: green;
      font-weight: bold;
    }

    .regresar {
      position: absolute;
      top: 20px;
      left: 20px;
      background: white;
      color: #3498db;
      padding: 8px 16px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      border: 2px solid #3498db;
      transition: 0.3s;
    }

    .regresar:hover {
      background-color: #3498db;
      color: white;
    }
  </style>
</head>
<body>

<a href="../admin_panel.php" class="regresar">← Volver al panel</a>

<div class="formulario">
  <h2>Registrar nueva factura</h2>
  <form method="POST">
    <label>Número de factura:</label>
    <input type="text" name="numero_factura" required>

    <label>Fecha de emisión:</label>
    <input type="date" name="fecha_emision" required>

    <label>Monto total:</label>
    <input type="number" name="monto_total" step="0.01" required>

    <label>Fecha de vencimiento:</label>
    <input type="date" name="fecha_vencimiento" required>

    <label>Estado de pago:</label>
    <select name="estado_pago" required>
      <option value="">Seleccione</option>
      <option value="pendiente">Pendiente</option>
      <option value="pagada">Pagada</option>
      <option value="vencida">Vencida</option>
    </select>

    <label>Orden de compra:</label>
    <select name="id_orden" required>
      <option value="">Seleccione una orden</option>
      <?php while ($orden = $ordenes->fetch_assoc()) { ?>
        <option value="<?php echo $orden['id_orden']; ?>">Orden #<?php echo $orden['id_orden']; ?></option>
      <?php } ?>
    </select>

    <input type="submit" value="Registrar Factura">
  </form>

  <div class="mensaje"><?php echo $mensaje; ?></div>
</div>

</body>
</html>