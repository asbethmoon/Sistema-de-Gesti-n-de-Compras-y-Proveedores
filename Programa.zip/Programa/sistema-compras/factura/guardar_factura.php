<?php 
include('../config/conexion.php'); 
$numero = $_POST['numero_factura']; 
$fecha = $_POST['fecha_emision']; 
$monto = $_POST['monto_total']; 
$vencimiento = $_POST['fecha_vencimiento']; 
$estado = $_POST['estado_pago']; 
$id_orden = $_POST['id_orden']; 
$sql = "INSERT INTO factura (numero_factura, fecha_emision, monto_total, fecha_vencimiento, estado_pago, id_orden) VALUES ('$numero', '$fecha', '$monto', '$vencimiento', '$estado', '$id_orden')"; 
if ($conn->query($sql) === TRUE) { 
    echo "✅ Factura registrada con éxito."; 
} else { 
    echo "❌ Error al registrar la factura: " . $conn->error; 
} 
$conn->close(); 
?>