<?php
include('../config/conexion.php');

$facturas = $conn->query("
  SELECT f.id_factura, f.numero_factura, f.fecha_emision, f.monto_total, 
         f.fecha_vencimiento, f.estado_pago, f.id_orden
  FROM factura f
  ORDER BY f.fecha_emision DESC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Listado de Facturas</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f3f6f9;
      padding: 30px;
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    th, td {
      padding: 12px 15px;
      border-bottom: 1px solid #ddd;
      text-align: center;
    }

    th {
      background-color: #2980b9;
      color: white;
    }

    tr:hover {
      background-color: #f2f2f2;
    }

    .volver {
      display: inline-block;
      margin-bottom: 20px;
      padding: 10px 16px;
      background-color: #3498db;
      color: white;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
    }

    .volver:hover {
      background-color: #21618c;
    }

    .estado-pendiente {
      color: #e67e22;
      font-weight: bold;
    }

    .estado-pagada {
      color: #27ae60;
      font-weight: bold;
    }

    .estado-vencida {
      color: #c0392b;
      font-weight: bold;
    }
  </style>
</head>
<body>

<a class="volver" href="../admin_panel.php">← Volver al panel</a>

<h2>📄 Facturas Registradas</h2>

<table>
  <thead>
    <tr>
      <th>ID</th>
      <th>Número</th>
      <th>Fecha Emisión</th>
      <th>Monto Total</th>
      <th>Vencimiento</th>
      <th>Estado de Pago</th>
      <th>ID Orden</th>
    </tr>
  </thead>
  <tbody>
    <?php while ($factura = $facturas->fetch_assoc()) {
      $estadoClass = 'estado-' . strtolower($factura['estado_pago']);
    ?>
      <tr>
        <td><?php echo $factura['id_factura']; ?></td>
        <td><?php echo htmlspecialchars($factura['numero_factura']); ?></td>
        <td><?php echo $factura['fecha_emision']; ?></td>
        <td>$<?php echo number_format($factura['monto_total'], 2); ?></td>
        <td><?php echo $factura['fecha_vencimiento']; ?></td>
        <td class="<?php echo $estadoClass; ?>"><?php echo ucfirst($factura['estado_pago']); ?></td>
        <td><?php echo $factura['id_orden']; ?></td>
      </tr>
    <?php } ?>
  </tbody>
</table>

</body>
</html>
