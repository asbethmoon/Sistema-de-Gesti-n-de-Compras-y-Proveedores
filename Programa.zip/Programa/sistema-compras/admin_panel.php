<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'administrador') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel del Administrador</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
      min-height: 100vh;
    }
    header {
      background-color: #2c3e50;
      color: white;
      padding: 20px;
      text-align: center;
    }
    h1 {
      margin: 0;
    }
    .contenedor {
      max-width: 900px;
      margin: 40px auto;
      background-color: white;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    }
    h2 {
      color: #34495e;
      margin-bottom: 30px;
      text-align: center;
    }
    .botones {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
    }
    .boton {
      display: inline-block;
      padding: 15px 25px;
      background-color: #3498db;
      color: white;
      text-decoration: none;
      border-radius: 10px;
      font-weight: bold;
      transition: background-color 0.3s ease;
      min-width: 200px;
      text-align: center;
    }
    .boton:hover {
      background-color: #2980b9;
    }
    .logout {
      display: block;
      margin-top: 40px;
      text-align: center;
    }
    .logout a {
      background-color: #e74c3c;
      padding: 10px 20px;
      border-radius: 8px;
      color: white;
      font-weight: bold;
      text-decoration: none;
      transition: 0.3s;
    }
    .logout a:hover {
      background-color: #c0392b;
    }
  </style>
</head>
<body>
<header>
  <h1>Panel de Administración</h1>
</header>
<div class="contenedor">
  <h2>Bienvenido(a), <?php echo $_SESSION['usuario']; ?> (Administrador)</h2>
  <div class="botones">
    <a class="boton" href="proveedor/registrar_proveedor.php">Registrar Proveedor</a>
    <a class="boton" href="proveedor/listar_proveedores.php">Ver Proveedores</a>
    <a class="boton" href="orden/registrar_orden.php">Registrar Orden</a>
    <a class="boton" href="orden/listar_ordenes.php">Ver Órdenes</a>
    <a class="boton" href="proveedor/historial_proveedor.php">Historial por Proveedor</a>
    <a class="boton" href="factura/registrar_factura.php">Registrar Factura</a>
    <a class="boton" href="factura/listar_facturas.php">Ver Facturas</a>
    <a class="boton" href="notificaciones/listar_notificaciones.php">Notificaciones</a>
    <a class="boton" href="orden/detalle_orden.php">Registrar Producto</a>
    <a class="boton" href="reportes/productos_mas_adquiridos.php">Productos más adquiridos</a>
    <a class="boton" href="usuarios/registrar_usuario.php">Registrar Usuario</a>
  </div>
  <div class="logout">
    <a href="cerrar_sesion.php">Cerrar sesión</a>
  </div>
</div>
</body>
</html>