<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../librerias\PHPMailer/src/PHPMailer.php';
require '../librerias\PHPMailer/src/SMTP.php';
require '../librerias\PHPMailer/src/Exception.php';
include('../config/conexion.php');

$mensaje = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];
    $rol = $_POST['rol'];
    $fecha = date('Y-m-d');

    // Verificar si el correo ya existe
    $verificar = $conn->prepare("SELECT id_usuario FROM usuario WHERE correo = ?");
    $verificar->bind_param("s", $correo);
    $verificar->execute();
    $resultado = $verificar->get_result();

    if ($resultado->num_rows > 0) {
        $mensaje = "⚠️ El correo ya está registrado.";
    } else {
        $stmt = $conn->prepare("INSERT INTO usuario (nombre, correo, contraseña, rol, fecha_registro)
                                VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nombre, $correo, $contrasena, $rol, $fecha);

        if ($stmt->execute()) {
            $mensaje = "✅ Usuario registrado correctamente.";

            // Enviar correo de bienvenida
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'adameproggramming@gmail.com';
                $mail->Password = 'Udpkctxvqwzwakwj';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('adameproggramming@gmail.com', 'Sistema de Compras');
                $mail->addAddress($correo, $nombre);

                $mail->isHTML(true);
                $mail->Subject = 'Bienvenido al sistema de compras';
                $mail->Body = "
                    <div style='font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; border-radius: 10px; border: 1px solid #ddd;'>
                      <h2 style='color: #3498db;'>¡Hola $nombre! 👋</h2>
                      <p>Has sido registrado en el <strong>sistema de compras</strong> con éxito.</p>
                      <ul style='line-height: 1.6;'>
                        <li>🧾 Rol asignado: <strong>$rol</strong></li>
                        <li>📅 Fecha de registro: <strong>$fecha</strong></li>
                        <li>🔐 Contraseña: <strong>$contrasena</strong></li>
                      </ul>
                      <p>Ya puedes acceder con tu correo y contraseña.</p>
                      <p style='margin-top: 20px;'>¡Gracias por unirte! 💙</p>
                      <hr>
                      <p style='font-size: 12px; color: #777;'>Este es un mensaje automático. No respondas a este correo.</p>
                    </div>
                ";

                $mail->send();
            } catch (Exception $e) {
                $mensaje .= "<br>⚠️ No se pudo enviar el correo: {$mail->ErrorInfo}";
            }
        } else {
            $mensaje = "❌ Error al registrar usuario: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registrar Usuario</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      background: linear-gradient(to right, #d0f0fd, #ffffff);
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    .formulario {
      background-color: #fff;
      padding: 40px;
      width: 460px;
      border-radius: 16px;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 25px;
    }

    label {
      font-weight: bold;
      display: block;
      margin-top: 15px;
    }

    input, select {
      width: 100%;
      padding: 12px;
      margin-top: 6px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 15px;
    }

    input[type="submit"] {
      margin-top: 25px;
      background-color: #3498db;
      color: white;
      font-weight: bold;
      border: none;
      cursor: pointer;
      transition: 0.3s ease;
    }

    input[type="submit"]:hover {
      background-color: #2980b9;
    }

    .mensaje {
      text-align: center;
      margin-top: 20px;
      font-weight: bold;
      color: #c0392b;
    }

    .mensaje.ok {
      color: #27ae60;
    }

    .volver {
      display: block;
      margin-top: 20px;
      text-align: center;
      background-color: #2ecc71;
      color: white;
      padding: 10px;
      border-radius: 8px;
      font-weight: bold;
      text-decoration: none;
    }

    .volver:hover {
      background-color: #27ae60;
    }
  </style>
</head>
<body>

<div class="formulario">
  <h2>🧑‍💼 Registrar Usuario</h2>

  <form method="POST">
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" required>

    <label for="correo">Correo:</label>
    <input type="email" name="correo" required>

    <label for="contrasena">Contraseña:</label>
    <input type="password" name="contrasena" required>

    <label for="rol">Rol:</label>
    <select name="rol" required>
      <option value="">Selecciona un rol</option>
      <option value="admin">Administrador</option>
      <option value="empleado">Empleado</option>
    </select>

    <input type="submit" value="Registrar Usuario">
  </form>

  <?php if ($mensaje): ?>
    <div class="mensaje <?php echo (str_starts_with($mensaje, '✅')) ? 'ok' : ''; ?>">
      <?php echo $mensaje; ?>
    </div>
  <?php endif; ?>

  <a class="volver" href="../admin_panel.php">← Volver al menú administrador</a>
</div>

</body>
</html>