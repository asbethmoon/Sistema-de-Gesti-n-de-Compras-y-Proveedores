<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
// Incluir PHPMailer manualmente (sin Composer)
require '../librerias/PHPMailer/src/Exception.php';
require '../librerias/PHPMailer/src/PHPMailer.php';
require '../librerias/PHPMailer/src/SMTP.php';
include('../config/conexion.php');
// Obtener datos del formulario
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$rol = $_POST['rol'];
$contraseña = password_hash("123456", PASSWORD_DEFAULT); // Contraseña temporal
// Insertar usuario en la base de datos
$sql = "INSERT INTO usuario (nombre, correo, contraseña, rol) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $nombre, $correo, $contraseña, $rol);
if ($stmt->execute()) {
    // Enviar correo de bienvenida
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'adameproggramming@gmail.com'; // Tu correo
        $mail->Password = 'udpkctxvqwzwakwj'; // Pégala aquí después
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('adameproggramming@gmail.com', 'Sistema de Compras');
        $mail->addAddress($correo, $nombre);
        $mail->isHTML(true);
        $mail->Subject = 'Bienvenida al sistema de compras';
        $mail->Body = "
            <h3>Hola, $nombre</h3>
            <p>Tu cuenta ha sido creada exitosamente.</p>
            <p><strong>Correo:</strong> $correo<br>
               <strong>Contraseña temporal:</strong> 123456<br>
               <strong>Rol asignado:</strong> $rol</p>
            <p>Por favor, cambia tu contraseña al iniciar sesión por primera vez.</p>
        ";
        $mail->send();
        echo "✅ Usuario registrado y correo enviado correctamente.";
    } catch (Exception $e) {
        echo "⚠️ Usuario registrado, pero error al enviar correo: {$mail->ErrorInfo}";
    }
} else {
    echo "❌ Error al registrar usuario.";
}
$stmt->close();
$conn->close();
?>
