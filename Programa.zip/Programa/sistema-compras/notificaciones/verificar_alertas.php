<?php
include('../config/conexion.php');

// Fecha actual
$hoy = date('Y-m-d');

// Buscar órdenes cuya fecha de entrega esté a 3 días o menos (y que no hayan sido notificadas aún)
$sql = "SELECT id_orden, fecha_entrega_estimada
        FROM orden_compra
        WHERE fecha_entrega_estimada IS NOT NULL
        AND fecha_entrega_estimada >= CURDATE()
        AND fecha_entrega_estimada <= DATE_ADD(CURDATE(), INTERVAL 3 DAY)";

$resultado = mysqli_query($conn, $sql);

// Revisar si ya existe una notificación por cada orden antes de insertarla
while ($orden = mysqli_fetch_assoc($resultado)) {
    $id_orden = $orden['id_orden'];

    // Verificar si ya existe una notificación activa para esta orden
    $verificar = "SELECT * FROM notificacion WHERE id_orden = $id_orden AND tipo = 'entrega' AND estado = 'activa'";
    $existe = mysqli_query($conn, $verificar);

    if (mysqli_num_rows($existe) == 0) {
        // Si no existe, insertamos la notificación
        $descripcion = "La orden #$id_orden está próxima a su fecha de entrega.";
        $fecha_generacion = date('Y-m-d');

        $insertar = "INSERT INTO notificacion (tipo, descripcion, fecha_generacion, id_orden, estado)
                     VALUES ('entrega', '$descripcion', '$fecha_generacion', $id_orden, 'activa')";

        mysqli_query($conn, $insertar);
    }
}

echo "🔔 Verificación de entregas completada.";
mysqli_close($conn);
?>