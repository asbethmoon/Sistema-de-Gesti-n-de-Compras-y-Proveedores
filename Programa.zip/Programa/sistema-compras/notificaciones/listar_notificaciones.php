<?php
include('../config/conexion.php');

$notificaciones = $conn->query("
  SELECT n.id_notificacion, n.tipo, n.descripcion, n.fecha_generacion, n.estado, 
         n.id_orden, p.nombre AS proveedor
  FROM notificacion n
  JOIN orden_compra o ON n.id_orden = o.id_orden
  JOIN proveedor p ON o.id_proveedor = p.id_proveedor
  ORDER BY n.fecha_generacion DESC
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>📢 Notificaciones</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f4f6f8;
      padding: 40px;
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 0 12px rgba(0,0,0,0.1);
    }

    th, td {
      padding: 14px;
      text-align: center;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #3498db;
      color: white;
    }

    tr:hover {
      background-color: #ecf0f1;
    }

    .tipo-aviso { color: #2980b9; font-weight: bold; }
    .tipo-alerta { color: #c0392b; font-weight: bold; }
    .tipo-recordatorio { color: #f39c12; font-weight: bold; }

    .estado-leida { color: #27ae60; font-weight: bold; }
    .estado-pendiente { color: #e67e22; font-weight: bold; }

    .volver {
      display: inline-block;
      margin-bottom: 20px;
      padding: 10px 18px;
      background-color: #3498db;
      color: white;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
    }

    .volver:hover {
      background-color: #21618c;
    }
  </style>
</head>
<body>

<a class="volver" href="../admin_panel.php">← Volver al panel</a>

<h2>📢 Notificaciones del Sistema</h2>

<?php if ($notificaciones->num_rows > 0): ?>
  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Tipo</th>
        <th>Descripción</th>
        <th>Fecha</th>
        <th>Proveedor</th>
        <th>ID Orden</th>
        <th>Estado</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($n = $notificaciones->fetch_assoc()) {
        $tipoClass = 'tipo-' . strtolower($n['tipo']);
        $estadoClass = 'estado-' . strtolower($n['estado']);
      ?>
        <tr>
          <td><?php echo $n['id_notificacion']; ?></td>
          <td class="<?php echo $tipoClass; ?>"><?php echo ucfirst($n['tipo']); ?></td>
          <td><?php echo htmlspecialchars($n['descripcion']); ?></td>
          <td><?php echo $n['fecha_generacion']; ?></td>
          <td><?php echo htmlspecialchars($n['proveedor']); ?></td>
          <td><?php echo $n['id_orden']; ?></td>
          <td class="<?php echo $estadoClass; ?>"><?php echo ucfirst($n['estado']); ?></td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
<?php else: ?>
  <p style="text-align:center; color: gray; font-size: 18px;">No hay notificaciones registradas.</p>
<?php endif; ?>

</body>
</html>